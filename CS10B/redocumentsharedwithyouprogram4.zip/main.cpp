#include <iostream>
#include "IntVector.h"

using namespace std;

void printIntVector(const IntVector& intVector);

int main(int argc, char* argv[])
{
    IntVector myIntVector(10, 9);

    unsigned size = myIntVector.size();

    cout << "The original size is: " << size << endl;

    unsigned capacity = myIntVector.capacity();

    cout << "The original capacity is: " << capacity << endl;

    bool isEmpty = myIntVector.empty();

    cout << "Empty? " << isEmpty << endl;

    const int& front_item = myIntVector.front();

    cout << "front item is: " << front_item << endl;

    const int& back_item = myIntVector.back();

    cout << "back item is: " << back_item << endl;

    cout << "The original IntVector is: " << endl;

    printIntVector(myIntVector);

    unsigned index1 = 5;

    const int& item_at_index1 = myIntVector.at(index1);

    cout << "item at index " << index1 << " is: " << item_at_index1 << endl;

//    unsigned index2 = 12;

//    const int& item_at_index2 = myIntVector.at(index2);

    myIntVector.expand();

    cout << "After the expand, the IntVector is: " << endl;

    printIntVector(myIntVector);

    myIntVector.expand(5);

    cout << "After the expand by 5, the IntVecctor is: " << endl;
    printIntVector(myIntVector);

    myIntVector.insert(0, 99);

    cout << "After insert(0, 99), the IntVecctor is: " << endl;
    printIntVector(myIntVector);

    myIntVector.erase(0);

    cout << "After erase(0), the IntVecctor is: " << endl;
    printIntVector(myIntVector);

    myIntVector.insert(5, 99);

    cout << "After insert(5, 99), the IntVecctor is: " << endl;
    printIntVector(myIntVector);

    myIntVector.erase(10);

    cout << "After erase(10), the IntVecctor is: " << endl;
    printIntVector(myIntVector);

    myIntVector.push_back(33);

    cout << "After push_back(33), the IntVecctor is: " << endl;
    printIntVector(myIntVector);

    myIntVector.pop_back();

    cout << "After pop_back(), the IntVecctor is: " << endl;
    printIntVector(myIntVector);

    myIntVector.clear();

    cout << "After clear(), the IntVecctor is: " << endl;
    printIntVector(myIntVector);

    for (int i = 0; i < 50; i++)
    {
        myIntVector.push_back(i);
    }

    cout << "After push_back(0, 49), the IntVecctor is: " << endl;
    printIntVector(myIntVector);

    myIntVector.resize(50, 66);

    cout << "After resize(50, 66), the IntVecctor is: " << endl;
    printIntVector(myIntVector);

    myIntVector.resize(40, 44);

    cout << "After resize(40, 44), the IntVecctor is: " << endl;
    printIntVector(myIntVector);

    myIntVector.resize(55, 77);

    cout << "After resize(55, 77), the IntVecctor is: " << endl;
    printIntVector(myIntVector);

    myIntVector.resize(105, 88);

    cout << "After resize(105, 88), the IntVecctor is: " << endl;
    printIntVector(myIntVector);

    myIntVector.reserve(60);

    cout << "After reserve(60), the IntVecctor is: " << endl;
    printIntVector(myIntVector);

    myIntVector.assign(65, 55);

    cout << "After assign(65, 55), the IntVecctor is: " << endl;
    printIntVector(myIntVector);

    int& value_at_index1 = myIntVector.at(33);

    cout << "value at index " << 33 << " is: " << value_at_index1 << endl;

    int& front_value = myIntVector.front();

    cout << "front value is: " << front_value << endl;

    int& back_value = myIntVector.back();

    cout << "back value is: " << back_value << endl;

    cout << "Value at index 100:" << endl;
    int& value_at_index = myIntVector.at(100);
}

void printIntVector(const IntVector& intVector)
{
    cout << "The size is: " << intVector.size() << ", the capacity is: " << intVector.capacity() << endl;

    for (unsigned i = 0; i < intVector.size(); ++i)
    {
        cout << "i: " << i << " ==> value: " << intVector.at(i) << endl;
    }
    cout << endl;
    cout << endl;
}
